// 游戏王制卡器 · 网页版
// 布局全部由 config.json 驱动；字体的墨迹偏移在浏览器里自动标定
const A = 'assets/';
const $ = id => document.getElementById(id);

let CFG = null;
let ART_IMG = null;
let OF_IMG = null;   // 超框图片（压在正常卡之上、文字之下）

// 两级缓存：① 卡图+卡框（不随超框变换变） ② 超框内衬+描边（按卡种固定）
let AF_CACHE = null, AF_KEY = '', OFC_CACHE = null, OFC_KEY = '';
let ART_SEQ = 0, OF_SEQ = 0;

// 两张图各自的变换：缩放 + 归一化偏移（相对目标矩形宽高）
const XF = {
  art: { zoom: 1, ox: 0, oy: 0 },
  of:  { zoom: 1, ox: 0, oy: 0 },
};
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

// 连接箭头状态（8 方向）
const ARROWS = { lefttop:0, top:0, righttop:0, left:0, right:0, leftdown:0, down:0, rightdown:0 };
const ARROW_ORDER = ['lefttop','top','righttop','left','right','leftdown','down','rightdown'];

// 卡名「自动配色」：官方规则——通常/效果/融合/同调/仪式=黑，其余=白
// 依据：超量(CL)名牌亮度 20.5、连接(LJ) 74.7 均为深色框，白字才看得清
const AUTO_NAME_BLACK = new Set(['通常', '效果', '融合', '同调', '仪式']);
function nameColor(type) {
  const sel = $('namecolor').value;
  if (sel === 'custom') return $('namecolorval').value;
  if (sel !== 'auto') return sel;
  return AUTO_NAME_BLACK.has(type) ? '#000000' : '#ffffff';
}
const IMGCACHE = new Map();
const INK = {};                 // 字体 → {dx,dy}（相对字号的墨迹偏移比例）

// 逐元素位置修正（由参考卡像素比对标定，来自 render.js）
const OFF = {
  name:   { dx: -3, dy: 11 },
  detail: { dx:  2, dy:  7 },
  pass:   { dx:  0, dy: 14 },
  atkdef: { dx:  0, dy:  5 },
  effect: { dx:  0, dy:  3 },
};
// 实测常量
const CAL = { advance: 0.95, lineFactor: 1.221 };
// 预览缩放：交互时用 0.5 倍，导出时才用 1.0（像素量差 4 倍）
const PREVIEW_S = 0.5;

// 只加载简体中文这条链真正用到的字体（省下约 25 MB 下载）
const FONTS = {
  'YGOLD ygo-sc': 'mold/font/YGOLDygosc.ttf',     // 卡名/类型行/效果文
  'Yu-Gi-Oh! Matrix': 'mold/font/YuGiOh!Matrix.ttf', // ATK/DEF
  'YGO-Password': 'mold/font/password.ttf',       // 卡号
  'ygo-link': 'mold/font/ygo_link.ttf',           // LINK 数值
};
const FAM = {
  'mold/font/YGOLDygosc.ttf': 'YGOLD ygo-sc',
  'mold/font/YGOLDDIYGB-Regular.ttf': 'YGOLD-DIY-GB',
  'mold/font/YGOLDARJenLei.ttf': 'YGOLD AR JenLei',
  'mold/font/YGOLDDFGLeisho4.ttf': 'YGOLD DFG Leisho 4',
  'mold/font/YuGiOh!Matrix.ttf': 'Yu-Gi-Oh! Matrix',
  'mold/font/password.ttf': 'YGO-Password',
  'mold/font/ygo_link.ttf': 'ygo-link',
};
const fam = p => FAM[p] || 'YGOLD ygo-sc';
const setStatus = t => { $('status').textContent = t; };

// 导入图片：用 objectURL（不走 base64）+ 立即降采样，避免大图占内存
async function loadScaled(file, maxSide) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = () => rej(new Error('图片解码失败'));
      i.src = url;
    });
    const s = Math.min(1, maxSide / Math.max(img.width, img.height));
    if (s >= 1) return img;                       // 本来就不大，原样用
    const c = document.createElement('canvas');
    c.width = Math.round(img.width * s);
    c.height = Math.round(img.height * s);
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    return c;                                     // 返回 canvas，drawImage 同样接受
  } finally {
    URL.revokeObjectURL(url);                     // 关键：及时释放
  }
}

function loadImg(src) {
  if (IMGCACHE.has(src)) return Promise.resolve(IMGCACHE.get(src));
  return new Promise((res, rej) => {
    const i = new Image();
    i.onload = () => { IMGCACHE.set(src, i); res(i); };
    i.onerror = () => rej(new Error('图片加载失败: ' + src));
    i.src = src;
  });
}

// ---------- 启动 ----------
async function boot() {
  setStatus('读取配置…');
  CFG = await (await fetch(A + 'config/config.json')).json();

  setStatus('加载字体…');
  for (const [family, path] of Object.entries(FONTS)) {
    const f = new FontFace(family, `url("${A}${path}")`);
    await f.load();
    document.fonts.add(f);
  }
  await document.fonts.ready;

  setStatus('标定字体墨迹…');
  for (const family of Object.keys(FONTS)) {
    const sample = /Matrix|Password/.test(family) ? '2' : '精';
    INK[family] = measureInk(family, sample, 200);
  }

  // 用 config 里的默认字号初始化滑块
  $('txtsize').value = CFG.text_size['简体中文'];
  $('tsv').textContent = CFG.text_size['简体中文'];

  setStatus('就绪');
  $('go').disabled = false;
  await render();
}

// 量一个字形在 Canvas 上相对基准点的墨迹偏移（textBaseline='top'）
function measureInk(family, sample, size) {
  const c = document.createElement('canvas');
  c.width = size * 3; c.height = size * 2;
  const g = c.getContext('2d', { willReadFrequently: true });
  g.fillStyle = '#000'; g.textBaseline = 'top';
  g.font = `${size}px "${family}"`;
  g.fillText(sample, 40, 40);
  const d = g.getImageData(0, 0, c.width, c.height).data;
  let x0 = 1e9, y0 = 1e9;
  for (let y = 0; y < c.height; y++) for (let x = 0; x < c.width; x++) {
    if (d[(y * c.width + x) * 4 + 3] > 32) { if (x < x0) x0 = x; if (y < y0) y0 = y; }
  }
  if (x0 > 1e8) return { dx: 0, dy: 0 };
  return { dx: (x0 - 40) / size, dy: (y0 - 40) / size };
}

// 墨迹左上角落在 (x,y) 时的绘制坐标
function place(family, x, y, size) {
  const r = INK[family] || { dx: 0, dy: 0 };
  return { x: x - r.dx * size, y: y - r.dy * size };
}

// 三种卡图适配 + 用户变换（缩放 / 偏移）
function drawArt(g, img, x, y, w, h, mode, xf) {
  xf = xf || { zoom: 1, ox: 0, oy: 0 };
  const cx = x + w / 2 + xf.ox * w;
  const cy = y + h / 2 + xf.oy * h;
  if (mode === 'stretch') {
    const dw = w * xf.zoom, dh = h * xf.zoom;
    g.drawImage(img, cx - dw / 2, cy - dh / 2, dw, dh);
    return;
  }
  const base = mode === 'contain'
    ? Math.min(w / img.width, h / img.height)
    : Math.max(w / img.width, h / img.height);
  const s = base * xf.zoom;
  const dw = img.width * s, dh = img.height * s;
  if (mode === 'contain') {           // 留边时先铺白底
    g.save(); g.fillStyle = '#fff'; g.fillRect(x, y, w, h); g.restore();
  }
  g.drawImage(img, cx - dw / 2, cy - dh / 2, dw, dh);
}

function wrapText(text, maxPx, sizePx) {
  const lines = [];
  for (const para of String(text).split('\n')) {
    let cur = '', w = 0;
    for (const ch of para) {
      const cw = /[\x00-\xff]/.test(ch) ? sizePx * 0.5 : sizePx * CAL.advance;
      if (w + cw > maxPx && cur) { lines.push(cur); cur = ch; w = cw; }
      else { cur += ch; w += cw; }
    }
    if (cur) lines.push(cur);
  }
  return lines;
}

const cardKind = t => t.includes('魔法') ? '魔法卡' : t.includes('陷阱') ? '陷阱卡' : '怪兽卡';
const isMonster = t => cardKind(t) === '怪兽卡';

// ---------- 渲染 ----------
async function render(quiet, full) {
  try {
    if (!quiet) setStatus('渲染中…');
    const cv = $('card'), g = cv.getContext('2d');
    const lang = '简体中文';
    const W = CFG.card_rect_w, H = CFG.card_rect_h;
    const S = full ? 1 : PREVIEW_S;              // 预览 / 导出两档
    cv.width = Math.round(W * S);
    cv.height = Math.round(H * S);
    g.setTransform(S, 0, 0, S, 0, 0);            // 之后全部按卡坐标画
    const type = $('type').value;
    const officer = true;

    g.clearRect(0, 0, W, H);
    g.imageSmoothingQuality = 'high';

    // 1. 卡图
    const isPend = type.includes('灵摆');
    // 灵摆卡图窗口更大更矮；普通卡用 ocard_*
    const artX = isPend ? CFG.LB_x : CFG.ocard_x;
    const artY = isPend ? CFG.LB_y : CFG.ocard_y;
    const artW = isPend ? CFG.LB_img_size_w : CFG.ocard_img_size_w;
    const artH = isPend ? CFG.LB_img_short_h : CFG.ocard_img_size_h;
    const art = ART_IMG || await loadImg(A + 'mold/demo_card.png');
    const fit = $('fit').value;
    const isOF = !!OF_IMG;

    // ① 卡图 + 卡框：与超框变换无关，缓存
    const afKey = [type, ART_SEQ, fit, S].join('|');
    if (!AF_CACHE || AF_KEY !== afKey) {
      const c = document.createElement('canvas');
      c.width = Math.round(W * S); c.height = Math.round(H * S);
      const x = c.getContext('2d');
      x.setTransform(S, 0, 0, S, 0, 0);
      x.imageSmoothingQuality = 'high';
      drawArt(x, art, artX, artY, artW, artH, fit, null);   // 正常卡图固定
      x.drawImage(await loadImg(A + CFG.base_images_official[type]), 0, 0);
      AF_CACHE = c; AF_KEY = afKey;
    }
    g.drawImage(AF_CACHE, 0, 0, W, H);

    // ② 超框图（每次画，因为可拖可缩放）+ ③ 内衬/描边（按卡种缓存）
    if (isOF) {
      const ofcKey = type + '|' + S;
      if (!OFC_CACHE || OFC_KEY !== ofcKey) {
        const c = document.createElement('canvas');
        c.width = Math.round(W * S); c.height = Math.round(H * S);
        const x = c.getContext('2d');
        x.setTransform(S, 0, 0, S, 0, 0);
        x.drawImage(await loadImg(A + CFG.overframe_inner[type]), 0, 0, W, H);
        x.drawImage(await loadImg(A + CFG.overframe_mask[type]), 0, 0, W, H);
        OFC_CACHE = c; OFC_KEY = ofcKey;
      }
      drawArt(g, OF_IMG, 0, 0, W, H, fit, XF.of);
      g.drawImage(OFC_CACHE, 0, 0, W, H);
    }

    // 3. 属性图标（魔法卡→魔，陷阱卡→罠，其余用所选属性）
    {
      const attrKey = type === '魔法卡' ? '魔' : type === '陷阱卡' ? '罠' : $('attr').value;
      const ap = CFG.attributes[lang][attrKey];
      if (ap) { const im = await loadImg(A + ap); g.drawImage(im, CFG.attribute_pos_x, CFG.attribute_pos_y, im.width, im.height); }
    }

    // 4. 等级星（从右往左）
    const lv = Math.max(0, Math.min(13, parseInt($('level').value) || 0));
    const isXyz = type.includes('超量');
    if (isMonster(type) && type !== '连接' && lv > 0) {
      if (isXyz) {
        // 阶级：从左往右；13 阶级用专门的起始 x，避免冲出边框
        const st = await loadImg(A + CFG.rank_img);
        const x0 = lv >= 13 ? CFG.rank_13_x : CFG.rank_x;
        const y0 = lv >= 13 ? CFG.rank_13_y : CFG.rank_y;
        for (let i = 0; i < lv; i++)
          g.drawImage(st, Math.round(x0 + i * CFG.rank_inter), y0, st.width, st.height);
      } else {
        const st = await loadImg(A + CFG.level_img);
        for (let i = 0; i < lv; i++)
          g.drawImage(st, Math.round(CFG.level_x - i * CFG.level_inter), CFG.level_y, st.width, st.height);
      }
    }

    // 4b. 连接箭头（8 方向，亮/灭）
    if (type === '连接') {
      for (const d of ARROW_ORDER) {
        const path = (ARROWS[d] ? CFG.arrows_on : CFG.arrows_off)[d];
        const im = await loadImg(A + path);
        g.drawImage(im, CFG['arrow_' + d + '_x'], CFG['arrow_' + d + '_y'], im.width, im.height);
      }
    }

    // 5. 文字
    g.textBaseline = 'top';
    g.fillStyle = '#000';
    const ls = CFG.letter_spacing[lang] || 0;

    // 卡名
    {
      const f = fam(CFG.card_name_font[lang]), s = CFG.card_name_size[lang];
      const p = place(f, CFG.card_name_posx[lang] + OFF.name.dx, CFG.card_name_posy[lang] + OFF.name.dy, s);
      g.font = `${s}px "${f}"`;
      if ('letterSpacing' in g) g.letterSpacing = ls + 'px';
      if (isOF) {                       // 超框无名牌，用白描边描边保证可读
        g.save();
        g.lineWidth = 10; g.lineJoin = 'round';
        g.strokeStyle = 'rgba(255,255,255,0.92)';
        g.strokeText($('name').value, p.x, p.y);
        g.restore();
      }
      g.save();
      g.fillStyle = nameColor(type);
      g.fillText($('name').value, p.x, p.y);
      g.restore();
      if ('letterSpacing' in g) g.letterSpacing = '0px';
    }

    // 类型行
    if (isMonster(type)) {
      const f = fam(CFG.detail_info_font[lang]), s = CFG.detail_size[lang];
      const d = $('detail').value.trim();
      const p = place(f, CFG.detail_posx[lang] + OFF.detail.dx, CFG.detail_posy[lang] + OFF.detail.dy, s);
      g.font = `${s}px "${f}"`;
      g.fillText(d ? `【${d}】` : '', p.x, p.y);
    } else {
      // 魔法卡 / 陷阱卡：用素材里的「【魔法卡】/【陷阱卡】」SVG
      const isMagic = type === '魔法卡';
      const mt = $('mteffect').value;
      const idx = isMagic ? 0 : 1;
      const svgPath = mt ? CFG.MT_type_full_svg[lang][idx] : CFG.MT_type_svg[lang][idx];
      const px = mt
        ? (isMagic ? CFG.MT_type_full_posx_M[lang] : CFG.MT_type_full_posx_T[lang])
        : (isMagic ? CFG.MT_type_posx_M[lang] : CFG.MT_type_posx_T[lang]);
      const sc = CFG.MT_type_scale[lang];
      const im = await loadImg(A + svgPath);
      g.drawImage(im, px, CFG.MT_type_posy[lang], im.width * sc, im.height * sc);
      // 效果图标（永续/装备/仪式/场地/反击/速攻）落在括号空位里
      if (mt && CFG.icons[mt]) {
        const ic = await loadImg(A + CFG.icons[mt]);
        g.drawImage(ic, CFG.icon_pos_x, CFG.icon_pos_y, ic.width, ic.height);
      }
    }

    // 效果文（字号可调；开启自动缩小时逐步减小直到行数装得下）
    {
      const f = fam(CFG.text_item_font[lang]);
      const kind = cardKind(type);
      const maxLines = CFG.text_line_num[kind];
      const body = $('text').value;
      const baseSize = CFG.text_size[lang];
      const userSize = parseInt($('txtsize').value) || baseSize;
      const auto = $('txtauto').value === '1';

      let s = userSize, lines = wrapText(body, CFG.rect_width[lang], s);
      if (auto) {
        while (s > 28 && lines.length > maxLines) {
          s--;
          lines = wrapText(body, CFG.rect_width[lang], s);
        }
      }
      const overflow = lines.length > maxLines;
      const shown = overflow ? lines.slice(0, maxLines) : lines;

      // 状态提示
      $('tsv').textContent = s + (s !== userSize ? '（已自动缩小）' : '');
      $('tsinfo').textContent = shown.length + '/' + maxLines + ' 行' + (overflow ? ' ⚠ 溢出' : '');

      const lineH = s * CAL.lineFactor;
      const posX = CFG.rect_pos_x[lang];
      const posY = isMonster(type) ? CFG.rect_pos_monster_y[lang] : CFG.rect_pos_mt_y[lang];
      g.font = `${s}px "${f}"`;
      shown.forEach((ln, i) => {
        const p = place(f, posX + OFF.effect.dx, posY + i * lineH + OFF.effect.dy, s);
        g.fillText(ln, p.x, p.y);
      });
    }

    // 灵摆：第二段效果文 + 左右刻度
    if (isPend) {
      const pf = fam(CFG.text_item_font[lang]);
      const ps = CFG.lb_text_size[lang];
      const pLines = wrapText($('ptext').value || '', CFG.lb_text_width, ps)
        .slice(0, CFG.lb_text_row_num);
      const pH = ps * CAL.lineFactor;
      g.font = `${ps}px "${pf}"`;
      g.fillStyle = '#000';
      pLines.forEach((ln, i) => {
        const p = place(pf, CFG.lb_text_x, CFG.lb_text_y[lang] + i * pH, ps);
        g.fillText(ln, p.x, p.y);
      });
      // 刻度数字（个位数与两位数位置不同）
      const zf = fam(CFG.text_item_font[lang]);
      const zs = CFG.lb_level_font_size;
      g.font = `${zs}px "${zf}"`;
      const zy = CFG.lb_level_left_single_pos_y;
      const L = ($('pscaleL').value || '').trim();
      const R = ($('pscaleR').value || '').trim();
      if (L) {
        const zx = L.length > 1 ? CFG.lb_level_left_double_pos_x : CFG.lb_level_left_single_pos_x;
        const p = place(zf, zx, zy, zs); g.fillText(L, p.x, p.y);
      }
      if (R) {
        const zx = R.length > 1 ? CFG.lb_level_right_double_pos_x : CFG.lb_level_right_single_pos_x;
        const p = place(zf, zx, zy, zs); g.fillText(R, p.x, p.y);
      }
    }

    // ATK / DEF（或 ATK / LINK）数字
    if (isMonster(type) && $('atk').value.trim() !== '') {
      const isLink = type === '连接';
      const f = fam(CFG.ATK_DEF_font_path);
      const s = Math.round(CFG.ATK_DEF_font_size / CFG.ATK_DEF_scale);
      const maxW = CFG.ATK_DEF_number_width;
      const y = CFG.ATK_DEF_number_y + OFF.atkdef.dy;
      g.font = `${s}px "${f}"`;

      const pairs = [[$('atk').value, CFG.ATK_number_x]];
      if (!isLink && $('def').value.trim() !== '') pairs.push([$('def').value, CFG.DEF_number_x]);
      for (const [val, nx] of pairs) {
        const p = place(f, nx + OFF.atkdef.dx, y, s);
        const tw = g.measureText(val).width;
        g.save();
        if (tw > maxW) { g.translate(p.x, p.y); g.scale(maxW / tw, 1); g.fillText(val, 0, 0); }
        else g.fillText(val, p.x, p.y);
        g.restore();
      }

      // LINK 数值：独立字体 + 横向拉伸
      if (isLink) {
        const n = linkCount();
        if (n > 0) {
          const lf = fam(CFG.link_font_path), lsz = CFG.LINK_font_size;
          const st = (CFG.LINK_font_stretch || 100) / 100;
          const p = place(lf, CFG.LINK_number_x, CFG.LINK_number_y, lsz);
          g.save();
          g.font = `${lsz}px "${lf}"`;
          g.translate(p.x, p.y);
          g.scale(st, 1);              // 横向拉伸 120%
          g.fillText(String(n), 0, 0);
          g.restore();
        }
      }
    }

    // 密码
    if ($('pass').value.trim() !== '') {
      const f = fam(CFG.pass_font_path), s = CFG.pass_font_size;
      const p = place(f, CFG.card_pass_x + OFF.pass.dx, CFG.card_pass_y + OFF.pass.dy, s);
      g.font = `${s}px "${f}"`;
      g.fillText($('pass').value.trim(), p.x, p.y);
    }

    // 包号
    if ($('pack').value.trim() !== '') {
      const f = fam(CFG.detail_info_font[lang]), s = CFG.pack_font_size;
      const p = place(f, CFG.card_pack_bottom_x, CFG.card_pack_bottom_y, s);
      g.font = `${s}px "${f}"`;
      g.fillText($('pack').value.trim(), p.x, p.y);
    }

    // 6. ATK/DEF（或 ATK/LINK）标签贴图
    if (isMonster(type) && $('atk').value.trim() !== '') {
      const svg = type === '连接' ? CFG.ATK_LINK_svg : CFG.ATK_DEF_svg;
      const im = await loadImg(A + svg);
      const sc = CFG.ATK_DEF_scale;
      g.drawImage(im, CFG.ATK_DEF_pos_x, CFG.ATK_DEF_pos_y, im.width * sc, im.height * sc);
    }

    // 7. 版权 SVG（简中 → 索引 2）
    {
      const idx = 2;
      const im = await loadImg(A + CFG.copyright_svgs_black[idx]);
      const sc = CFG.copyright_scale[idx];
      g.drawImage(im, CFG.copyright_x[idx], CFG.copyright_y, im.width * sc, im.height * sc);
    }

    // 8. 稀有度（screen 叠加）
    const rar = $('rarity').value;
    if (rar && CFG.rare_imgs[rar]) {
      try {
        const im = await loadImg(A + CFG.rare_imgs[rar][0]);
        g.globalCompositeOperation = 'screen';
        g.drawImage(im, 0, 0, W, H);
        g.globalCompositeOperation = 'source-over';
      } catch (e) {
        // 本版本未打包稀有度素材，静默跳过
        g.globalCompositeOperation = 'source-over';
      }
    }

    setStatus(quiet ? '就绪' : '渲染完成');
    return cv;
  } catch (e) {
    setStatus('错误：' + e.message);
    console.error(e);
    throw e;
  }
}

// ---------- 导出 ----------
async function exportPng() {
  setStatus('全尺寸导出中…');
  const cv = await render(true, true);          // 全尺寸
  cv.toBlob(blob => {
    if (!blob) { setStatus('导出失败'); return; }
    const url = URL.createObjectURL(blob);
    const a = $('dl');
    a.href = url;
    a.download = 'card_' + Date.now() + '.png';
    a.style.display = 'block';
    a.textContent = '点此保存图片（' + (blob.size / 1048576).toFixed(1) + ' MB）';
    setStatus('已生成，可保存');
    render(true, false);                        // 回到预览档
  }, 'image/png');
}

// ---------- 交互 ----------
$('ofimg').addEventListener('change', async e => {
  const f = e.target.files[0];
  if (!f) { OF_IMG = null; OF_SEQ++; autoRender(); return; }
  setStatus('处理超框图片…');
  try {
    OF_SEQ++; OF_IMG = await loadScaled(f, 2600);
    setStatus('就绪');
    render(true);
  } catch (err) {
    setStatus('超框图片加载失败：' + err.message);
  }
});
$('art').addEventListener('change', async e => {
  const f = e.target.files[0];
  if (!f) return;
  setStatus('处理卡图…');
  try {
    ART_SEQ++; ART_IMG = await loadScaled(f, 2600);   // 长边压到 2600，足够 1626 宽的卡面
    setStatus('就绪');
    render(true);
  } catch (err) {
    setStatus('卡图加载失败：' + err.message);
  }
});
const linkCount = () => ARROW_ORDER.reduce((n, d) => n + (ARROWS[d] ? 1 : 0), 0);
function syncArrows() {
  document.querySelectorAll('#arrows button').forEach(b => b.classList.toggle('on', !!ARROWS[b.dataset.dir]));
  $('arrowcount').textContent = linkCount() + ' 个箭头';
}
document.querySelectorAll('#arrows button').forEach(b => {
  b.addEventListener('click', () => { ARROWS[b.dataset.dir] = ARROWS[b.dataset.dir] ? 0 : 1; syncArrows(); autoRender(); });
});
syncArrows();

['namecolor', 'namecolorval'].forEach(id => $(id).addEventListener('input', autoRender));

$('go').addEventListener('click', exportPng);

// 自动重绘：防抖 150ms + 串行化，避免并发 render 互相覆盖
let _timer = null, _chain = Promise.resolve();
function autoRender(fast) {
  clearTimeout(_timer);
  _timer = setTimeout(() => {
    _chain = _chain.then(() => render(true)).catch(() => {});
  }, fast ? 50 : 150);
}
// 文本类：听 input（边打字边更新）
['name', 'detail', 'text', 'atk', 'def', 'pass', 'pack', 'txtsize', 'ptext', 'pscaleL', 'pscaleR'].forEach(id =>
  $(id).addEventListener('input', autoRender));
// 选择类：听 change
['type', 'attr', 'level', 'rarity', 'fit', 'mteffect', 'txtauto'].forEach(id =>
  $(id).addEventListener('change', autoRender));

// ---------- 位置/缩放调整 ----------
// 只有超框图片可调整；正常卡图固定
const curTarget = () => ({ xf: XF.of, w: CFG.card_rect_w, h: CFG.card_rect_h });

function syncSliders() {
  const { xf } = curTarget();
  $('zoom').value = Math.round(xf.zoom * 100);
  $('ox').value = Math.round(xf.ox * 100);
  $('oy').value = Math.round(xf.oy * 100);
  $('zv').textContent = Math.round(xf.zoom * 100) + '%';
  $('xv').textContent = Math.round(xf.ox * 100) + '%';
  $('yv').textContent = Math.round(xf.oy * 100) + '%';
}

['zoom', 'ox', 'oy'].forEach(id => $(id).addEventListener('input', () => {
  const { xf } = curTarget();
  xf.zoom = parseFloat($('zoom').value) / 100;
  xf.ox = parseFloat($('ox').value) / 100;
  xf.oy = parseFloat($('oy').value) / 100;
  $('zv').textContent = $('zoom').value + '%';
  $('xv').textContent = $('ox').value + '%';
  $('yv').textContent = $('oy').value + '%';
  autoRender();
}));

$('reset').addEventListener('click', () => {
  XF.of = { zoom: 1, ox: 0, oy: 0 };
  syncSliders();
  render();
});

// 画布拖动 + 双指缩放
{
  const cv = $('card');
  const ptrs = new Map();
  let pinchD = 0;
  const cardPxPerCssPx = () => CFG.card_rect_w / cv.getBoundingClientRect().width;
  const dist = () => {
    const [a, b] = [...ptrs.values()];
    return Math.hypot(a.x - b.x, a.y - b.y);
  };

  cv.addEventListener('pointerdown', e => {
    if (!OF_IMG) return;                 // 没有超框图时不可拖动
    cv.setPointerCapture(e.pointerId);
    ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (ptrs.size === 2) pinchD = dist();
  });

  cv.addEventListener('pointermove', e => {
    if (!ptrs.has(e.pointerId)) return;
    if (!OF_IMG) return;
    const prev = ptrs.get(e.pointerId);
    ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const { xf, w, h } = curTarget();

    if (ptrs.size === 1) {
      const k = cardPxPerCssPx();
      xf.ox = clamp(xf.ox + (e.clientX - prev.x) * k / w, -0.5, 0.5);
      xf.oy = clamp(xf.oy + (e.clientY - prev.y) * k / h, -0.5, 0.5);
      syncSliders();
      autoRender(true);
    } else if (ptrs.size === 2) {
      const d = dist();
      if (pinchD > 0) { xf.zoom = clamp(xf.zoom * d / pinchD, 0.2, 3); pinchD = d; }
      syncSliders();
      autoRender(true);
    }
  });

  const up = e => {
    ptrs.delete(e.pointerId);
    if (ptrs.size < 2) pinchD = 0;
  };
  cv.addEventListener('pointerup', up);
  cv.addEventListener('pointercancel', up);
}

boot().catch(e => setStatus('启动失败：' + e.message));
